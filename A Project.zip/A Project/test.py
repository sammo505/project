from flask import Flask, render_template, flash, redirect, url_for
from flask_mail import Mail, Message

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Required for flashing messages

# Configure Flask-Mail settings
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'fafo1612@gmail.com'  # Replace with your email
app.config['MAIL_PASSWORD'] = 'njryxxemnjekosiy' # Replace with your email password

mail = Mail(app)

# Route to send an email with a link
@app.route('/send_link_email/<email>/<path:link>')
def send_link_email(email, link):
    # Create the message
    msg = Message(
        subject="Check out this link!",
        sender=app.config['MAIL_USERNAME'],
        recipients=[fahimfoysal18102003@gmail.com]
    )

    # HTML message content with a link
    msg.html = f"""
    <html>
        <body>
            <p>Hello,</p>
            <p>We thought you might be interested in this link:</p>
            <a href="{https://youtu.be/p-8Im_Q7jPI?si=a9eJvTdQLh9TdyNY}">{link}</a>
            <br><br>
            <p>Enjoy!</p>
            <p>Best Regards,<br>Your Flask App Team</p>
        </body>
    </html>
    """

    # Send the email
    try:
        mail.send(msg)
        flash('Email sent successfully! Check your inbox.', 'success')
    except Exception as e:
        flash(f'Failed to send email: {str(e)}', 'danger')
    
    return redirect(url_for('home'))

# Dummy Home Route (for redirection)
@app.route('/')
def home():
    return "Welcome to the Home Page! Use /send_link_email/<email>/<link> to send an email."

# Run the app
if __name__ == '__main__':
    app.run(debug=True)
